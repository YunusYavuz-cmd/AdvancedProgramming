#include <iostream>
#include <string>

int main()
{
	int i = 0;
	int j = -1;
	string s = "I'm syntactically correct";
	if (i == 0) {j==1;}
	{
		if(s == "I'm correct")
		{
			s = "Ups, actually I'm syntactically wrong...";
		}}
		cout << s << endl;
	}
	return 0;
}